declare const overlay: string;
export default overlay;
